<h1>New <?php echo sfInflector::humanize($this->getSingularName()) ?></h1>

[?php include_partial('form', array('form' => $form)) ?]
