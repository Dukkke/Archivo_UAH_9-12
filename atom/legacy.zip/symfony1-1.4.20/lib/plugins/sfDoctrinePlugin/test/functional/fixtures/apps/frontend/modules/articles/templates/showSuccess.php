<h1><?php echo $article ?></h1>
