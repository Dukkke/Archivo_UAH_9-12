<form action="<?php echo url_for('attachment/index') ?>" method="post">
  <table>
    <?php echo $form ?>
  </table>
  <p><button type="submit">submit</button></p>
</form>
