<?php

/**
 * ResourceType filter form.
 *
 * @package    symfony12
 * @subpackage filter
 * @author     Your name here
 * @version    SVN: $Id: ResourceTypeFormFilter.class.php 27742 2010-02-08 15:46:35Z Kris.Wallsmith $
 */
class ResourceTypeFormFilter extends BaseResourceTypeFormFilter
{
  public function configure()
  {
  }
}
